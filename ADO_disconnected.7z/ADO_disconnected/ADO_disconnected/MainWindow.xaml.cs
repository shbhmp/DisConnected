﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ADO_disconnected
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection connection = new SqlConnection(ConnectionString);
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        DataSet dataset = new DataSet();
        SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder();
        SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
        public MainWindow()
        {
            InitializeComponent();
        }
        public void LoadGrid()
        {
            try
            {
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                //string query = "Select * from StudentDetails454";
                //Command.CommandText = query;
                sqlDataAdapter = new SqlDataAdapter("Select * from StudentDetails454", connection);
                sqlDataAdapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;
                sqlCommandBuilder.DataAdapter = sqlDataAdapter;
                sqlDataAdapter.Fill(dataset);
                dgStudent.DataContext = dataset.Tables[0];
            }
            catch (SqlException Exception)
            {
                MessageBox.Show(Exception.Message);
            }
            catch (Exception Exception)
            {

                MessageBox.Show(Exception.Message);
            }
           
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadGrid();
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            int StudentCode = int.Parse(txtStudCode.Text);
            string StudentName = txtStudName.Text;
            string DepartmentName = txtDeptName.Text;
            string DOB = Convert.ToDateTime(txtDOB.Text).ToString("MM/dd/yyyy");
            string Address = txtAddress.Text;
            int Year = int.Parse(txtYear.Text);

            DataRow dataRow = dataset.Tables[0].NewRow();
            dataRow[0] = StudentCode.ToString();
            dataRow[1] = StudentName;
            dataRow[2] = DepartmentName;
            dataRow[3] = DOB;
            dataRow[4] = Address;
            dataRow[5] = Year.ToString();

            dataset.Tables[0].Rows.Add(dataRow);
            MessageBox.Show("Data Added Sucessfully into the DataSet");
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            int StudentCode = int.Parse(txtStudCode.Text);
            DataRow SearchedRow = dataset.Tables[0].Rows.Find(StudentCode);
            if (SearchedRow != null)
            {
                txtStudCode.Text = SearchedRow[0].ToString();
                txtStudName.Text = SearchedRow[1].ToString();
                txtDeptName.Text = SearchedRow[2].ToString();
                txtDOB.Text = SearchedRow[3].ToString();
                txtAddress.Text = SearchedRow[4].ToString();
                txtYear.Text = SearchedRow[5].ToString();
            }
        }

        private void btndetete_Click(object sender, RoutedEventArgs e)
        {
            int StudentCode = int.Parse(txtStudCode.Text);
            DataRow deleterow = dataset.Tables[0].Rows.Find(StudentCode);
            
            dataset.Tables[0].Rows.Remove(deleterow);
            MessageBox.Show("Row deleted sucessfully from dataset");
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int StudentCode = int.Parse(txtStudCode.Text);
            string StudentName = txtStudName.Text;
            string DepartmentName = txtDeptName.Text;
            string DOB = Convert.ToDateTime(txtDOB.Text).ToString("MM/dd/yyyy");
            string Address = txtAddress.Text;
            int Year = int.Parse(txtYear.Text);

            DataRow Searchedrow = dataset.Tables[0].Rows.Find(StudentCode);



            Searchedrow[0] = StudentCode.ToString();
            Searchedrow[1] = StudentName;
            Searchedrow[2] = DepartmentName;
            Searchedrow[3] = DOB;
            Searchedrow[4] = Address;
            Searchedrow[5] = Year.ToString();

            
            MessageBox.Show("Data Updated Sucessfully into the DataSet");
        }

        private void btnWriteAlltoDatabase_Click(object sender, RoutedEventArgs e)
        {
            sqlDataAdapter.Update(dataset);
            MessageBox.Show("All Changes written to Database sucessfully");
        }
    }
}
